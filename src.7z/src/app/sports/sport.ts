export interface ISports{
    playerId: number;
    playerRank: number;
    playerName: string;
    playerCountry: string;
    battingAvg: number;
    description: string;
    runs: number;
    wickets: number;
    imageUrl: string;
    imageUrl1: string;
}
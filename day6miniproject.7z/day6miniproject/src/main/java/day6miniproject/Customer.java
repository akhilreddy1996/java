package day6miniproject;

public class Customer {

	private int customerId;
	
	private String customerName;
	
	 Address address=new Address();
	
	 Account account[]=new Account[5];
	
	

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Customer()
	{
		
	}
	
}
